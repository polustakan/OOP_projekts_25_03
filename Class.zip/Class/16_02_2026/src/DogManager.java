import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class DogManager {
     private ArrayList<Dog> dogs = new ArrayList<>();
     public void addDog(Dog d0){
         dogs.add(d0);
     }
     public void printAll(){
         for (Dog i:dogs){
             i.print();
         }
     }
     public void readFromFile(){
         try {
             FileReader fr = new FileReader("input.txt");
             Scanner scFile = new Scanner(fr);
             while (scFile.hasNextLine()){
                 String[] parts = scFile.nextLine().split(",");
                 String name = parts [0];
                 int age = Integer.parseInt(parts[1].trim());
                 String breed = parts[2];
                 String color = parts[3];
                 dogs.add(new Dog(name,age,breed,color));
             }
         } catch (FileNotFoundException e) {
             throw new RuntimeException(e);
         }
     }
     public void findDogByName(String name){
         for (Dog i:dogs){
             String name1 = i.getName().toLowerCase();
             if (name1.contains(name.toLowerCase())){
                 i.print();
                 System.out.println("This dog doen't exist");
                 break;
             }
         }
         System.out.println("This dog doen't exist");
     }
    public void writeFile(){
        try {
            FileWriter fw = new FileWriter("output.txt");
            for (Dog i: dogs){
                String outputStr ="";
                outputStr = i.toString();
                fw.write(outputStr);
            }
            fw.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
