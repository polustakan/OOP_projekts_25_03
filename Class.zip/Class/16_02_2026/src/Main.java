import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DogManager manager = new DogManager();
//        manager.ReadFromFile();

//        ArrayList<Dog> dogs  =new ArrayList<>();
//        Dog d1 = new Dog();
//        d1.name = "Vladimir";
//        d1.breed = "Vladimirman";
//        d1.age = 3;
//        d1.color = "BrBr";
//        manager.addDog(new Dog("Alex",5,"DiDi","orange"));
//        manager.addDog(new Dog("Fominchik",1,"Dvorterjer"));
//        d3.print();
//        d1.print();
//        d2.print();
//        d1.command();
//        d1.voice();
//        d1.eat();
//        manager.addDog(new SmartDog("Volodenka", 1,"latvian","white"));
//        manager.addDog(new Dog());

//        dogs.add(d2);
//        dogs.add(d3);
//        dogs.add(0,d4);
//        for (Dog i: dogs){
//            i.print();
//        }
//        dogs.get(0).print();
//        for (Dog i: dogs){
//            i.print();
//        }
//        System.out.println(dogs.size());
//        dogs.set(0,d3);
//        for (Dog i: dogs){
//            i.print();
//        }
//        d4.writeFile(dogs);

//        d4.print();
//        d4.command();
//        d4.voice();
//        System.out.println(d4);
//        d4.eat();
        int choice;
        do {
            System.out.println("======DOG MENU======");
            System.out.println("1. Add dog");
            System.out.println("2. Add smart dog");
            System.out.println("3. Show all dogs");
            System.out.println("4. Find dog by name");
            System.out.println("5. Exit");
            System.out.println("====================");
            choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    System.out.println("1. Add dog");
                    System.out.println("Enter name");
                    String name = sc.nextLine();
                    System.out.println("Enter age");
                    int age = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter breed");
                    String breed = sc.nextLine();
                    System.out.println("Enter color");
                    String color = sc.nextLine();
                    manager.addDog(new Dog(name, age, breed, color));
                    System.out.println("Dog is addded");
                    break;
                case 2:
                    System.out.println("2. Add smart dog");
                    System.out.println("Enter name");
                    String sname = sc.nextLine();
                    System.out.println("Enter age");
                    int sage = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter breed");
                    String sbreed = sc.nextLine();
                    System.out.println("Enter color");
                    String scolor = sc.nextLine();
                    System.out.println("Enter iq");
                    float iq = sc.nextFloat();
                    sc.nextLine();
                    manager.addDog(new SmartDog(sname, sage, sbreed, scolor, iq));
                    System.out.println("Smart dog is addded");
                    break;
                case 3:
                    System.out.println("3. Show all dogs");
                    manager.readFromFile();
                    manager.printAll();
                    break;
                case 4:
                    System.out.println("4. Find dog by name");
                    manager.readFromFile();
                    manager.findDogByName(sc.next());
                    break;
                case 5:
                    System.out.println("Go away");
                    break;
                default:
                    System.out.println("Invalid choise");
            }

        } while (choice != 5);
//        manager.printAll();
        manager.writeFile();
    }
}