import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Dog {
    private String name;
    private int age;
    private String breed;
    private String color;
    public Dog(String name, int age, String breed, String color){
        this.name=name;
        this.age=age;
        this.breed=breed;
        this.color=color;
    }
    public Dog(){

    }
    public Dog(String name, int age, String breed){
        this.name=name;
        this.age=age;
        this.breed=breed;
        this.color="black";
    }
    public void print(){
        System.out.println("The dog's name is "+name+", its breed is "+breed+", its age is "+age+", its colour is "+color+".");

    }
    public void command(){
        System.out.println("Owner: "+name+" voice!");
    }
    public  void voice(){
        System.out.println(name+": \"Vau-vau!\"");
    }
    public void eat(){
        System.out.println(name+": blows");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return  name + '\'' +
                ", age=" + age +
                ", breed='" + breed + '\'' +
                ", color='" + color + '\''+"\n" ;
    }

}
