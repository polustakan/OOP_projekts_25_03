import java.util.Random;

public class SmartDog extends Dog{
    private float iq;
    public SmartDog(String name, int age, String breed, String color, float iq){
        super(name, age, breed, color);
        this.iq = iq;
    }
    public SmartDog(String name, int age, String breed, String color){
        super(name, age, breed, color);
        Random rand = new Random();
        this.iq = rand.nextFloat(-10,11);
    }
    public void print(){
        System.out.println("The dog's name is "+getName()+", its breed is "+getBreed()+", its age is "+getAge()+", its colour is "+getColor()+", iq = "+iq+".");
    }

    public void voice(){
        if (iq>6){
            System.out.println(getName()+": \"Vau!\"");
        } else if (iq<1){
            System.out.println(getName()+": blows owner");
        } else {
            System.out.println(getName()+": \"Vau-vau!\"");
        }
    }

    public float getIq() {
        return iq;
    }

    public void setIq(float iq) {
        this.iq = iq;
    }

    @Override
    public String toString() {
        return super.toString()+
                "iq=" + iq +"\n";
    }
}
