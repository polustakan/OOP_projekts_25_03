public class Main {
    public static void main(String[] args) {
        Fish shark = new Fish("NotVladimir","shark","male",3, 150,"ocean");
        Reptile frog = new Reptile("Vladimir","frog","male",1,1,2);
        shark.print();
    }
}