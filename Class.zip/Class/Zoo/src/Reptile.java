public class Reptile extends Animal{
    private double leap;
    public Reptile(String name,String species,String gender, int age, int weight,double leap){
        super(name,species,gender, age,weight);
        this.leap = leap;
    }
    public void leaping(){
        System.out.println(getName()+" leaps about "+getLeap()+" meters");
    }

    public double getLeap() {
        return leap;
    }

    public void setLeap(double leap) {
        this.leap = leap;
    }
}
