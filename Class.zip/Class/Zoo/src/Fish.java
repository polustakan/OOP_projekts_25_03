public class Fish extends Animal{
    private String habitat;
    public Fish(String name,String species,String gender, int age, int weight,String habitat){
        super(name,species,gender, age,weight);
        this.habitat  =habitat;
    }
    public void print(){
        System.out.printf(super.toString()+" and lives in "+getHabitat());
    }
    public void swim(){

    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }



}
