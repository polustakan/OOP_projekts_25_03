public class Animal {
    private String name;
    private String species;
    private String gender;
    private int age;
    private int weight;
    public Animal (String name,String species,String gender, int age, int weight){
        this.name = name;
        this.species = species;
        this.gender = gender;
        this.age = age;
        this.weight = weight;
    }
    public void print(){
        System.out.printf(getName()+"'s spiecies is "+getSpecies()+", its gender is "+getGender()+", its age is .%2f"+getAge()+"years, its weight is .%2f"+getWeight());
    }
    public void sleep(){
        System.out.println(getName()+" is sleeping");
    }
    public void eat(){
        System.out.println(getName()+" is eating");
    }
    public void move(){
        System.out.println(getName()+" is sleeping");
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return       getName()+"'s spiecies is "+getSpecies()+", its gender is "+getGender()+", its age is "+getAge()+" years, its weight is "+getWeight()+" kilos";

    }
}
